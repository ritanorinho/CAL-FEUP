var searchData=
[
  ['trimsolution',['trimSolution',['../class_application.html#a9c49d3db72acb40a8f5498325a55fc22',1,'Application']]]
];
