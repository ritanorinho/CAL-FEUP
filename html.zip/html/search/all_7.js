var searchData=
[
  ['ordersolutionbyprice',['orderSolutionByPrice',['../class_application.html#a67c3441283f22262f51a013b71691afe',1,'Application']]]
];
